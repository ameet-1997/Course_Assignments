import pandas as pd
import numpy as np
import os 
import matplotlib.pyplot as plt
from functions import get_purity

