mkdir -p /usr/local/opt/boost/lib/
mkdir -p /usr/local/Cellar/vowpal-wabbit/8.4.0_2/lib/
cp lib/libboost_program_options-mt.dylib /usr/local/opt/boost/lib/
cp lib/liballreduce.0.dylib /usr/local/Cellar/vowpal-wabbit/8.4.0_2/lib/
cp lib/libvw.0.dylib /usr/local/Cellar/vowpal-wabbit/8.4.0_2/lib/
