
/**
 *<p> package to implement linear support vector machines for classification </p>
 */
package ml.LSVC;