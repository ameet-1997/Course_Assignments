
/**
 * Package for Linear support vector machines for regression
 *
 */
package ml.LSVR;