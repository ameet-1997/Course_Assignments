
/**
 *Package to implement the naive bayes' algorithm for classification
 */
package ml.NaiveBayes;