
/**
 * Class to perform nearest neighbour Approaches (Regression and classification)
 */
package ml.knn;