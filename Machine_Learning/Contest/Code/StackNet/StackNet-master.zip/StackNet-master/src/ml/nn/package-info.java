
/**
 * Package dedicated to neutral networks
 *
 */
package ml.nn;