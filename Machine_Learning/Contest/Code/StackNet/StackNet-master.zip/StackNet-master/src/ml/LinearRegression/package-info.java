
/**
 * main package to run linear regression (and not classification) models
 * This contains both solving for RMSE and MAE.
 */
package ml.LinearRegression;