
/**
 * <p> purpose of this package is to provide some additional miscellaneous functionality like printing.
 *
 */
package misc;