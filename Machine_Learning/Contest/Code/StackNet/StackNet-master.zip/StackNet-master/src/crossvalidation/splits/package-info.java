
/**
 * <p> Methods for splitting the data divided into 4 main categories:
 * <ol>
 * <li> Random </li>
 * <li> Selective</li>
 * <li> Bootstrapping</li>
 * <li> kfold</li>
 * </ol>
 * </p>
 *
 */
package crossvalidation.splits;