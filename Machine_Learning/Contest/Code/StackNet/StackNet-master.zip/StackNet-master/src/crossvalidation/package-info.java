
/**
 * <p> Package to assist in cross-validation for modelling purposes. It will include
 * <ol>
 * <li>Metrics</li>
 * <li>Splits</li>
 * </ol>
 * </p>
 */
package crossvalidation;