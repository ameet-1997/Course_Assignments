
/**
 * Package for various stuff that help 
 *
 */

package utilis;