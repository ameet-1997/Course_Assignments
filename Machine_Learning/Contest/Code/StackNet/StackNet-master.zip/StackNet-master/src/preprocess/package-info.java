
/**
 *<p> Basic pre-processing steps for modelling such as <p>
 * <ol>
 * <li> Scallling</li>
 * <li> Binning </>
 * <li></li> 
 * </ol> 
 * 
 * <p> some will be added later on</p>
 */
package preprocess;