
/**
 * *<p> algorithms for scaling </p>
 */
package preprocess.scaling;