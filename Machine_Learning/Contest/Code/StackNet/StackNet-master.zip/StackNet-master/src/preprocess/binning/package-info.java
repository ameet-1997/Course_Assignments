
/**
 * *<p> algorithms for scaling </p>
 */
package preprocess.binning;