
/**
 * <p> provides functionality for basic stats, such as computing Mean, Standard deviation and more <p>
 * 
 */
package Stats;