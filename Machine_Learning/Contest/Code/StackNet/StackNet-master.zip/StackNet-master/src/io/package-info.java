
/**
 * <p> purpose of the package is to provide functionality for input/output (reading files). </p>
 */
package io;