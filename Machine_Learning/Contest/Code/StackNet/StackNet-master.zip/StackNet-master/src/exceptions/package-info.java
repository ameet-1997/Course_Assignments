
/**
 * <p> 
 * Methods for handling exceptions.
 * </p>
 *
 */
package exceptions;