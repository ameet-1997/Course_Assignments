
/**
 *<p> Purpose of the package is to provide functionality for appending (as in add new "columns" to an existing array or the opposite </p>
 */
package manipulate.append;