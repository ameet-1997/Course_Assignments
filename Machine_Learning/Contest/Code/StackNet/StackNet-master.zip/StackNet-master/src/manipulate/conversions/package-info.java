
/**
 * <p> Purpose of this package is to provide functionality for Array's conversions. Conversions can be of 2 kind:
 * <ol>
 * <li>Types</li>
 * <li>Dimensions</li>
 * </ol>
 * </p>
 *
 */
package manipulate.conversions;