
/**
 * <p> purpose of the class is to make sub-arrays from existed arrays. </p> It is divided in 2 types:
 * <ol>
 * <li> Column selections</li>
 * <li> Row selections</li>
 * </ol>
 *
 */
package manipulate.select;