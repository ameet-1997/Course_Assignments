
/**
 * <p> Class to provide basic operations that take an array and use it in conjunction with a scalar e.g. Array A +-* scalar</p> 
 *
 */
package manipulate.scalars;