
/**
 * <p> purpose of this class is to provide functionality for replacing some parts of an array with other <p/>
 */
package manipulate.insertions;