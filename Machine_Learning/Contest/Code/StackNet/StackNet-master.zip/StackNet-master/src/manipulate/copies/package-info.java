/**
 * <p> main purpose of this package is to copy the elements of an array or List to a new object</p>
 */
package manipulate.copies;