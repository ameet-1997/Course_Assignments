/**
 * <p> This package will perform matrix operations including
 *  <ol>
  <li>Transpose</li>
  <li>Dot product</li>
  <li>Matrix multiplication (multiple dot products)</li>   
  <li>Matrix inverse</li>      
  </ol>
  </p> 
 *
 */
package manipulate.matrixoperations;