/**
 * <p> Purpose of this package is to provide fuctionality for merging(or concatenating ) arrays
 *
 */
package manipulate.merges;