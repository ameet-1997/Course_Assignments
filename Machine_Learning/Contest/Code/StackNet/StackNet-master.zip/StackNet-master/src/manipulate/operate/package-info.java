/**
 * <p> purpose of the class is to provide basic operations among arrays and more specifically:
 * <ol>
 * <li>Additions </li>
 * <li>Subtractions </li>
 * <li>Multiplications </li>
 * <li>Divisions </li>
 * </ol>
 * 
 *</p>
 */
package manipulate.operate;